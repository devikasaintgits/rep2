import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {

  constructor() { }

  MovieName=['AVENGERS: END GAME','KALANK'];
  MovieImage=['../../assets/img/Movie4.jpg','../../assets/img/Movie5.jpg'];
  MovieId=[0,1,2];

  Users=['Jithu','Pushp','Gaurav','Sandeep','Roctim'];

 
  ngOnInit() {
  }

}
