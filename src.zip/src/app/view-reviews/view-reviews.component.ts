import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-reviews',
  templateUrl: './view-reviews.component.html',
  styleUrls: ['./view-reviews.component.css']
})
export class ViewReviewsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
