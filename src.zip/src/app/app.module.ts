import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeLoginComponent } from './home-login/home-login.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { AboutsComponent } from './abouts/abouts.component';
import { ContactComponent } from './contact/contact.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { SeatLayoutComponent } from './seat-layout/seat-layout.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AddMoviesComponent } from './add-movies/add-movies.component';
import { AddShowComponent } from './add-show/add-show.component';
import { PaymentComponent } from './payment/payment.component';
import { BookingsComponent } from './bookings/bookings.component';
import { ViewReviewsComponent } from './view-reviews/view-reviews.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeLoginComponent,
    UserHomeComponent,
    AboutsComponent,
    ContactComponent,
    MovieDetailsComponent,
    SeatLayoutComponent,
    AdminHomeComponent,
    AddMoviesComponent,
    AddShowComponent,
    PaymentComponent,
    BookingsComponent,
    ViewReviewsComponent,
    
  
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
