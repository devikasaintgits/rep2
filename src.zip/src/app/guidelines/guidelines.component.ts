import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guidelines',
  templateUrl: './guidelines.component.html',
  styleUrls: ['./guidelines.component.css']
})
export class GuidelinesComponent implements OnInit {
  imag: string;

  constructor() { }

  ngOnInit() {
    this.imag = "assets/images/Theater3.jpg";
  }

}
