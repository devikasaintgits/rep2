import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-show',
  templateUrl: './add-show.component.html',
  styleUrls: ['./add-show.component.css']
})
export class AddShowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
