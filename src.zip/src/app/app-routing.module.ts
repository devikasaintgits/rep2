import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeLoginComponent } from './home-login/home-login.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { ContactComponent } from './contact/contact.component';
import { AboutsComponent } from './abouts/abouts.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { SeatLayoutComponent } from './seat-layout/seat-layout.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AddMoviesComponent } from './add-movies/add-movies.component';
import { AddShowComponent } from './add-show/add-show.component';
import { PaymentComponent } from './payment/payment.component';
import { BookingsComponent } from './bookings/bookings.component';
import { ViewReviewsComponent } from './view-reviews/view-reviews.component';



const routes: Routes = [
  {path: '',  redirectTo: '/Home', pathMatch: 'full' },
  {path:'Home',component:HomeLoginComponent},
  {path:'User',component:UserHomeComponent},
  {path:'Abouts', component: AboutsComponent },
  {path:'Contact',component:ContactComponent},  
  {path:'Movie/:Id',component: MovieDetailsComponent},
  {path:'Seats',component:SeatLayoutComponent},
  {path:'AdminHome',component:AdminHomeComponent},
  {path:'AddMovies', component: AddMoviesComponent },
  {path:'AddShow' , component: AddShowComponent } , 
  {path:'Payment' , component: PaymentComponent } ,   
  {path:'Bookings' , component: BookingsComponent } ,
  {path:'ViewReviews' , component:ViewReviewsComponent } ,
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
