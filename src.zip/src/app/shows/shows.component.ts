import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shows',
  templateUrl: './shows.component.html',
  styleUrls: ['./shows.component.css']
})
export class ShowsComponent implements OnInit {
  movie1: string;
  movie2: string;

  constructor() { }

  ngOnInit() {
    this.movie1 = "assets/images/Desert.jpg";
    this.movie2 = "assets/images/Jellyfish.jpg";
  }

}
